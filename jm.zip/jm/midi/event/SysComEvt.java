/*

<This Java Class is part of the jMusic API version 1.65, March 2017.>:54  2001

Copyright (C) 2000 Andrew Sorensen & Andrew Brown

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or any
later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

package jm.midi.event;
/**************************************************************
Provides an interface for System Common Events.  System Common 
events will usually be placed into an Event List in which they 
will be classed as Event Types.  SysComEvt extends the 
Event interface.
@author Andrew Sorensen
***************************************************************/

public interface SysComEvt extends Event
{

}


